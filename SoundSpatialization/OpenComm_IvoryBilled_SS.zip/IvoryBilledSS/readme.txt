SoundSpatialization Demo -- Risa Naka (rn96) -- Modified November 27, 2010

###############################################################################
###############################################################################

	I. Summary (0001)

	II. Project (0002)
		A. Activity (0002A)
		B. ContentProvider (0002B)
		C. Service (0002C)
		D. Broadcast Receiver (0002D)
		E. Resources (0002E)
	
	III. Versions (0003)

###############################################################################
###############################################################################

	I. Summary (0001)
	
		8000 bytes/sec = 16-bit/8-bit * 1 channels * 8000kHz

#######################################


###############################################################################
###############################################################################

	II. Project (0002)

#######################################

		A. Activity (0002A)
			1. MultiUserDemo: launches UI for multiuser demo;
				demonstrates the ability to have multiple users (sound sources)
			2. SingleUserDemo: launches UI for singleuser demo;
				demonstrates the ability for single user (sound source)
				changing positions

#######################################
				
		B. Content Provider (0002B)
			1. UserProvider: Store the user information in SQLite Database

#######################################

		C. Broadcast Receiver (0002C)

#######################################

		D. Service (0002D)
			1. SoundService: Manipulate the sound as it is sent to the phone

			
#######################################

		E. Resources (0002E)
			layout/demo_single.xml: Layout for SingleUserDemo.java
			layout/demo_multi.xml: Layout for MultiUserDemo.java
			values/strings.xml: Strings for the various layouts
###############################################################################
###############################################################################			