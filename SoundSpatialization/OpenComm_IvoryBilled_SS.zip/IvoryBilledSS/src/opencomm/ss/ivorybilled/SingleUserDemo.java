package opencomm.ss.ivorybilled;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/** This activity demonstrates the ability to take a
 * single sound source and update sound spatialization
 * manipulation each time it is moved to a new location */

public class SingleUserDemo extends Activity {
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		// set the layout to demo_single.xml
        setContentView(R.layout.demo_single);
		
		// find toggle buttons
        Button rOne = (Button) findViewById(R.id.sOne);
        Button rThree = (Button) findViewById(R.id.sThree);
        Button rFive = (Button) findViewById(R.id.sFive);
        Button rSixteen = (Button) findViewById(R.id.sSixteen);
        Button rEighteen = (Button) findViewById(R.id.sEighteen);
        Button rTwenty = (Button) findViewById(R.id.sTwenty);
		Log.i("SingleUserDemo", "RadioButtons set");
		
		// create SS manipulation for the sound source
		final AudioSS aSource = new AudioSS(400, 420); // region 18
		Log.i("SingleUserDemo", "AudioSS initialized at Region " + aSource.getRegion());
		
		// prep the sound source
		final byte[] bSource = prepFile(R.raw.lowc);
		aSource.play();
		// write bSource into AudioSS aSource
		new Thread() {
			public void run() {
				// write bSource 5000 bytes at a time
				for (int i = 0; i < 640000; i = i + 0) {
					byte[] bWrite = new byte[12800];
					for (int j = 0; j < 12800; j++) {
						bWrite[j] = bSource[i];
						i++;
					}
					aSource.write(bWrite);
					Log.i("SingleUserDemo", "Written");
				}
			}
		}.start();
		
		// set the click listener
		rOne.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		aSource.moveTo(80, 60);
        		Log.i("SingleUserDemo", "Region updated to " + aSource.getRegion());
        	}
        });
		
		rThree.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		aSource.moveTo(400, 60);
        		Log.i("SingleUserDemo", "Region updated to " + aSource.getRegion());
        	}
        });
		
		rFive.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		aSource.moveTo(720, 60);
        		Log.i("SingleUserDemo", "Region updated to " + aSource.getRegion());
        	}
        });
		
		rSixteen.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		aSource.moveTo(80, 420);
        		Log.i("SingleUserDemo", "Region updated to " + aSource.getRegion());
        	}
        });
		
		rEighteen.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		aSource.moveTo(400, 420);
        		Log.i("SingleUserDemo", "Region updated to " + aSource.getRegion());
        	}
        });
		
		rTwenty.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		aSource.moveTo(720, 420);
        		Log.i("SingleUserDemo", "Region updated to " + aSource.getRegion());
        	}
        });
    }
    
    /** = byte source of raw file id to read into an AudioSS instance */
    public byte[] prepFile(int id) {
    	byte[] music = new byte[640000];
		InputStream is = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
    	try {
			is = getResources().openRawResource(id);
			Log.i("SingleUserDemo", "prepFile - input stream: " + id);
			bis = new BufferedInputStream(is);
			Log.i("SingleUserDemo", "prepFile - buffered input stream: " + id);
			dis = new DataInputStream(bis);
			Log.i("SingleUserDemo", "prepFile - data input stream: " + id);
		}
		catch (Exception e) {
			Log.e("SingleUserDemo", "prepFile - " + id + " not read");
		}		
		try {
			int i = 0;
			while (dis.available() > 0) {
				music[i] = dis.readByte();
				i++;
			}
		} catch (IOException e) {
			Log.e("SingleUserDemo", "prepFile - " + id + " not read into byte array");
		}
		Log.i("SingleUserDemo", "prepFile - " + id + " read into byte array");
		return music;
    } // end prepFile method
}