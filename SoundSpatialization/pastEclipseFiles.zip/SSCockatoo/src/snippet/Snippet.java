package snippet;

public class Snippet {
	public static void main(String[] args) {
		/SSCockatoo/res/raw/test.wav
	}
}

