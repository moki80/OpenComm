package ssDemo.BluethroatedBarbet;

import ssDemo.toucan.R;
import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.*;
import android.view.View.*;
import android.widget.*;

public class AudioDemo extends Activity {
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        final MediaPlayer mp = MediaPlayer.create(getBaseContext(), R.raw.raw_test);
        final ToggleButton start = (ToggleButton) findViewById(R.id.start);
        final Button left = (Button) findViewById(R.id.left);
        final Button right = (Button) findViewById(R.id.right);
        final Button front = (Button) findViewById(R.id.front);
        start.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		if (start.isChecked()) {//perform action if it's on
        			mp.start();
        		}
        		else { // pause the music
        			mp.pause();
        		}
        	}
        });
        left.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		mp.setVolume(0.20f, 0.80f);
        	}
        });
        right.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		mp.setVolume(0.80f, 0.20f);
        	}
        });
        front.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		mp.setVolume(0.5f, 0.5f);
        	}
        });
    }
}