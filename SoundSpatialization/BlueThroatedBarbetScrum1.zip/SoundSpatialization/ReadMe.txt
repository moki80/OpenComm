Risa Naka (rn96) -- OpenComm Group -- Sound Spatialization
Sprint 2: Blue-Throated Barbet -- September 29, 2010 @ 7:25AM

##############################
##############################

	Versions:

			1: Create UI with play/pause toggle button to control music
			2: Add to UI left, center, right buttons to mimic spatial hearing
			3: Produce sound using MediaPlayer
			4: Change volume of left/right ear by clicking on buttons and changing volumes

##############################

	Classes/Interfaces:
	
			AudioDemo (C): demoes the most recent version; achieves sound spatialization by difference in volume in each ear and interaural time difference
			AudioPlayer (I): interface used to control 2 Audio objects to achieve sound spatialization
			AudioRaw (C): class that controls 2 AudioTrack objects to achieve sound spatialization (incomplete)

##############################

	Changes to be Implemented
	
			1: Utilize given degree/distance to determine volume in each ear
			2: Utilize position clicked to calculate degree/distance of location from origin



