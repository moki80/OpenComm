package opencomm.noranq.pineapple_daiquiri;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.widget.TextView;
import android.widget.Toast;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.ListIterator;
import android.view.View;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.drawable.Drawable;


/** last updated 11/3/10
 * Author: Nora Ng-Quinn 
 */

//TODO need to change to official icon width/height parameters, can only be done when can resize icon images
public class UserView extends Activity {
	//private User MainUser; // The user that owns this UserView
	//private PrivateSpace ViewPS; // The PrivateSpace this UserView is representing
	//private HashMap<User,Icon> PeopleIconHash; // A hashmap, give User object, returns icon associated with this person 
	private UVdraw uvDraw;
	private int screenWidth=270;
	private int screenHeight=400;
	
    /** Called when the activity is first created. */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        //Load the View to draw on

        setContentView(new UVdraw(this,screenWidth,screenHeight));  
    }
    
    


}


