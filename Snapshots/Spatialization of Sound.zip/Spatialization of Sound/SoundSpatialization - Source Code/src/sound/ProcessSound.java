/**
 *
 * @author Sanket Jain
 * @author Akshay Wadhwa
 * 
 **/


package sound;

public class ProcessSound
{

    final double D2R = Math.PI / 180;
    final double R2D = 180 / Math.PI;
    protected double azimuth = 0;
    protected double init_azimuth = 0;
    protected double elevation = 0;
    protected double R ;
    protected double init_R;
    protected double prev_R;


    /**
     *
     * @param in: Input byte array of the sound (channelized two dimensional array)
     * @param out: Output byte array of the sound (channelized two dimensional array)
     * @param frames: Number of frames to process
     * @param threshold: Threshold angle to introduce discontinuity
     **/

    public void process(double[][] in, double[][] out, int frames, int threshold)
    {
        double A = D2R * azimuth;
        double E = D2R * elevation;
        double sample = 0;
        threshold = threshold / 2; //Since, the total angle of one rotation is coming to be 180, and not 360.


        for (int i = 0; i < frames; i++)
        {
            sample = in[0][i];
            if((azimuth >= 0 && azimuth < threshold) )
            {
                //Left Only Front
                out[0][i] = sample * (R * Math.cos(A) * Math.cos(E) + R * Math.sin(E)/2 );
                out[1][i] = sample * (R * Math.sin(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 1.7;
            }
            else if(azimuth <180 && azimuth >= (180 - threshold) )
            {
                //Left Only Back
                out[0][i] = sample * (R * Math.cos(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 1.6;
                out[1][i] = sample * (R * Math.sin(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 2.2;
            }
            else if ((azimuth < 90 && azimuth >= (90 - threshold)))
            {
                //Right Only Front
                out[0][i] = sample * (R * Math.cos(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 1.7;
                out[1][i] = sample * (R * Math.sin(A) * Math.cos(E) + R * Math.sin(E)/2 );
            }
            else if(azimuth >= 90 && azimuth < (90 + threshold))
            {
                //Right Only Back
                out[0][i] = sample * (R * Math.cos(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 2.2;
                out[1][i] = sample * (R * Math.sin(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 1.6;
            }
            else if( azimuth >= threshold && azimuth < (90-threshold) )
            {
                //Both Front
                out[0][i] = sample * (R * Math.cos(A) * Math.cos(E) + R * Math.sin(E)/2 );
                out[1][i] = sample * (R * Math.sin(A) * Math.cos(E) + R * Math.sin(E)/2 );
            }
            else
            {
                //Both Back
                out[0][i] = sample * (R * Math.cos(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 2;
                out[1][i] = sample * (R * Math.sin(A) * Math.cos(E) + R * Math.sin(E)/2 ) / 2;
            }
        }

    } // End of function

} //End of Class