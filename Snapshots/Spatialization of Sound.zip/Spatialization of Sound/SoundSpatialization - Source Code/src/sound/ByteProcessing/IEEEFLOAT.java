/**
 *
 * @author Sanket Jain
 * 
 **/


package sound.ByteProcessing;

public class IEEEFLOAT extends AbstractByteConverter implements ByteConvert
{
  int     bytes;
  boolean bigEndian;

  public IEEEFLOAT(int bytes, boolean bigEndian)
  {
    this.bytes = bytes;
    this.bigEndian = bigEndian;
  }

  public void fromBytes(byte[] in, double[] out, int frames, int numchannels, int channel)
  {
    int offset = 0;
    if (bytes == 4)
    {
      for (int i = 0; i < frames; i++)
      {
        offset = (i * numchannels * bytes) + channel * bytes;
        out[i] = getFloat(in, offset);
      }
    }
    else if (bytes == 8)
    {
      for (int i = 0; i < frames; i++)
      {
        offset = (i * numchannels * bytes) + channel * bytes;
        out[i] = getDouble(in, offset);
      }
    }
  }

  public void toBytes(double[] in, byte[] out, int frames, int numchannels, int channel)
  {
    int offset = 0;
    if (bytes == 4)
    {
      for (int i = 0; i < frames; i++)
      {
        offset = (i * numchannels * bytes) + channel * bytes;
        fromFloat(in[i], out, offset);
      }
    }
    else if (bytes == 8)
    {
      for (int i = 0; i < frames; i++)
      {
        offset = (i * numchannels * bytes) + channel * bytes;
        fromDouble(in[i], out, offset);
      }
    }
  }

  private double getFloat(byte[] b, int offset)
  {
    double sample = 0;
    int ret = 0;
    int length = bytes;
    for (int i = 0; i < bytes; i++, length--)
    {
      ret |= ((int) (b[offset + i] & 0xFF) << ((((bigEndian) ? length : (i + 1)) * 8) - 8));
    }
    sample = Float.intBitsToFloat(ret);
    return sample;
  }

  private double getDouble(byte[] b, int offset)
  {
    double sample = 0;
    long ret = 0;
    int length = bytes;
    for (int i = 0; i < bytes; i++, length--)
    {
      ret |= ((int) (b[offset + i] & 0xFF) << ((((bigEndian) ? length : (i + 1)) * 8) - 8));
    }
    sample = Double.longBitsToDouble(ret);
    return sample;
  }

  private final void fromFloat(double value, byte[] b, int offset)
  {
    int ival = -1;
    ival = Float.floatToIntBits((float) value);
    if (bigEndian)
    {
      b[offset + 0] = (byte) ((ival & 0xff000000) >> (8 * 3));
      b[offset + 1] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
      b[offset + 2] = (byte) ((ival & 0x0000ff00) >> 8);
      b[offset + 3] = (byte) (ival & 0x000000ff);
    }
    else
    {
      b[offset + 0] = (byte) (ival & 0x000000ff);
      b[offset + 1] = (byte) ((ival & 0x0000ff00) >> 8);
      b[offset + 2] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
      b[offset + 3] = (byte) ((ival & 0xff000000) >> (8 * 3));
    }
  }

  private final void fromDouble(double value, byte[] b, int offset)
  {
    long ival = -1;
    ival = Double.doubleToLongBits(value);
    if (bigEndian)
    {
      b[offset + 0] = (byte) ((ival & 0xff000000) >> (8 * 3));
      b[offset + 1] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
      b[offset + 2] = (byte) ((ival & 0x0000ff00) >> 8);
      b[offset + 3] = (byte) (ival & 0x000000ff);
    }
    else
    {
      b[offset + 0] = (byte) (ival & 0x000000ff);
      b[offset + 1] = (byte) ((ival & 0x0000ff00) >> 8);
      b[offset + 2] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
      b[offset + 3] = (byte) ((ival & 0xff000000) >> (8 * 3));
    }
  }

    public void fromBytes(byte[] in, double[][] out, int frames) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void toBytes(double[][] in, byte[] out, int frames) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}