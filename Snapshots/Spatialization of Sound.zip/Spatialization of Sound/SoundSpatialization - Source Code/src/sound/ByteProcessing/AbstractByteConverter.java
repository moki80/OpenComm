/**
 *
 * @author Sanket Jain
 *
 **/


package sound.ByteProcessing;

public abstract class AbstractByteConverter implements ByteConvert
{
  public void fromBytes(byte[] in, double[][] out, int frames)
  {
    for (int c = 0; c < out.length; c++)
    {
      fromBytes(in, out[c], frames, out.length, c);
    }
  }

  public void toBytes(double[][] in, byte[] out, int frames)
  {
    for (int c = 0; c < in.length; c++)
    {
      toBytes(in[c], out, frames, in.length, c);
    }
  }
}
