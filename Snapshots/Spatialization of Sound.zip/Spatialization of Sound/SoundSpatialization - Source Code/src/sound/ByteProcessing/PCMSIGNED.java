/**
 *
 * @author Sanket Jain
 *
 **/


package sound.ByteProcessing;

public class PCMSIGNED extends AbstractByteConverter implements ByteConvert
{
  int     bytes;
  boolean bigEndian;

  public PCMSIGNED(int bytes, boolean bigEndian)
  {
    this.bytes = bytes;
    this.bigEndian = bigEndian;
  }

  public void fromBytes(byte[] in, double[] out, int frames, int numchannels, int channel)
  {
    int offset = 0;
    for (int i = 0; i < frames; i++)
    {
      offset = (i * numchannels * bytes) + channel * bytes;
      out[i] = getDouble(in, offset);
    }
  }

  public void toBytes(double[] in, byte[] out, int frames, int numchannels, int channel)
  {
    int offset = 0;
    for (int i = 0; i < frames; i++)
    {
      offset = (i * numchannels * bytes) + channel * bytes;
      fromDouble(in[i], out, offset);
    }
  }

  private double getDouble(byte[] b, int offset)
  {
    double sample = 0;
    int ret = 0;
    int length = bytes;
    for (int i = 0; i < bytes; i++, length--)
    {
      ret |= ((int) (b[offset + i] & 0xFF) << ((((bigEndian) ? length : (i + 1)) * 8) - 8));
    }
    switch (bytes)
    {
      case 1 :
        if (ret > 0x7F)
        {
          ret = ~ret + 1;
          ret &= 0x7F;
          ret = ~ret + 1;
        }
        sample = (double) ((double) ret / (double) Byte.MAX_VALUE);
        break;
      case 2 :
        if (ret > 0x7FFF)
        {
          ret = ~ret + 1;
          ret &= 0x7FFF;
          ret = ~ret + 1;
        }
        sample = (double) ((double) ret / (double) Short.MAX_VALUE);
        break;
      case 3 :
        if (ret > 0x7FFFFF)
        {
          ret = ~ret + 1;
          ret &= 0x7FFFFF;
          ret = ~ret + 1;
        }
        sample = (double) ((double) ret / 8388608f);
        break;
      case 4 :
        sample = (double) ((double) ret / (double) Integer.MAX_VALUE);
        break;
    }
    return sample;
  }

  private final void fromDouble(double value, byte[] b, int offset)
  {
    int ival = -1;
    switch (bytes)
    {
      case 1 : // 8 bit
        b[offset + 0] = new Float(value * (double) Byte.MAX_VALUE).byteValue();
        break;
      case 2 : // 16 bit
        short sval = new Float(value * (double) Short.MAX_VALUE).shortValue();
        if (bigEndian)
        {
          b[offset + 0] = (byte) ((sval & 0x0000ff00) >> 8);
          b[offset + 1] = (byte) (sval & 0x000000ff);
        }
        else
        {
          b[offset + 0] = (byte) (sval & 0x000000ff);
          b[offset + 1] = (byte) ((sval & 0x0000ff00) >> 8);
        }
        break;
      case 3 : // 24 bit
        ival = new Float(value * (double) 8388608).intValue();
        if (bigEndian)
        {
          b[offset + 0] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
          b[offset + 1] = (byte) ((ival & 0x0000ff00) >> 8);
          b[offset + 2] = (byte) (ival & 0x000000ff);
        }
        else
        {
          b[offset + 0] = (byte) (ival & 0x000000ff);
          b[offset + 1] = (byte) ((ival & 0x0000ff00) >> 8);
          b[offset + 2] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
        }
        break;
      case 4 : // 32 bit
        ival = new Float(value * (double) Integer.MAX_VALUE).intValue();
        if (bigEndian)
        {
          b[offset + 0] = (byte) ((ival & 0xff000000) >> (8 * 3));
          b[offset + 1] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
          b[offset + 2] = (byte) ((ival & 0x0000ff00) >> 8);
          b[offset + 3] = (byte) (ival & 0x000000ff);
        }
        else
        {
          b[offset + 0] = (byte) (ival & 0x000000ff);
          b[offset + 1] = (byte) ((ival & 0x0000ff00) >> 8);
          b[offset + 2] = (byte) ((ival & 0x00ff0000) >> (8 * 2));
          b[offset + 3] = (byte) ((ival & 0xff000000) >> (8 * 3));
        }
        break;
    }
  }
}