/**
 *
 * @author Sanket Jain
 * 
 **/


package sound.ByteProcessing;

public class LE16Bit extends AbstractByteConverter implements ByteConvert
{
  public void fromBytes(byte[] in, double[] out, int frames, int numchannels, int channel)
  {
    int offset = 0;
    for (int i = 0; i < frames; i++)
    {
      offset = (i * numchannels * 2) + channel * 2;
      out[i] = ((in[offset + 1] << 8) | (in[offset] & 0xFF)) / 32768.;
    }
  }

  public void toBytes(double[] in, byte[] out, int frames, int numchannels, int channel)
  {
    int offset = 0;
    for (int i = 0; i < frames; i++)
    {
      offset = (i * numchannels * 2) + channel * 2;
      out[offset] = (byte) (((int) (in[i] * 32768.)) & 0xFF);
      out[offset + 1] = (byte) (((int) (in[i] * 32768.)) >> 8 & 0xFF);
    }
  }

    public void fromBytes(byte[] in, double[][] out, int frames) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void toBytes(double[][] in, byte[] out, int frames) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
