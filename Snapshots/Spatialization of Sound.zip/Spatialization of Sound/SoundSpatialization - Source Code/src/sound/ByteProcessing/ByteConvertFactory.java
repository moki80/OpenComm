/**
 *
 * @author Sanket Jain
 *
 **/


package sound.ByteProcessing;

import javax.sound.sampled.AudioFormat;

public class ByteConvertFactory
{
  public static ByteConvert createConverter(AudioFormat format)
  {
      try
      {
          if (format.getEncoding() == AudioFormat.Encoding.PCM_SIGNED && format.getSampleSizeInBits() >= 8 && format.getSampleSizeInBits() <= 32)
          {
              return new PCMSIGNED(format.getSampleSizeInBits() / 8, format.isBigEndian());
          }

          if (format.getEncoding() == WaveTool.IEEE_FLOAT && (format.getSampleSizeInBits() == 32 || format.getSampleSizeInBits() == 64))
          {
              return new IEEEFLOAT(format.getSampleSizeInBits() / 8, format.isBigEndian());
          }
          if (format.getEncoding() == AudioFormat.Encoding.PCM_SIGNED && format.getSampleSizeInBits() == 16  && !format.isBigEndian())
          {
              System.out.println("1");
              return new LE16Bit();
          }

          return null;

      }
      catch(Exception e)
      {
          System.out.println("byteConvertFactory: Error " + e);
          e.printStackTrace();
          return null;
      }
    
  }
}