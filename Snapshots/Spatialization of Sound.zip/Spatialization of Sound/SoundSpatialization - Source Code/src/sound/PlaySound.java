/**
 *
 * @author Sanket Jain
 * @author Akshay Wadhwa
 * 
 **/


package sound;

import sound.ByteProcessing.ByteConvert;
import sound.ByteProcessing.ByteConvertFactory;
import java.util.Arrays;
import javax.sound.sampled.*;
import javax.sound.sampled.Mixer.Info;
import java.io.*;
import javax.swing.JOptionPane;


class PlaySound extends Thread
{
    static final int BUFFSIZE = 4096; //with space for overlap-add fft
    static final int WORKSIZE = 256; //BUFFSIZE / 2; //actual working size    
    int threshold = 60;
    String filename;

    AudioInputStream audioInputStream;
    AudioFormat orgFormat, audioFormat;
    SourceDataLine sourceDataLine;
    public ProcessSound ap;

    byte        tempBuffer[];       //Holds the input sound file as a byte array
    double      workBuffer[][];     //Holds the input sound file as a two dimensional channelized byte array
    double      workBuffer2[][];    //Holds the input sound file as a two dimensional channelized byte array
    byte        outBuffer[] ;       //Holds the output sound file as a byte array
    
    ByteConvert convin;      
    ByteConvert convout;     


    
    /**
     * Constructor: PlaySound: Sets the Java Sound API sound parameters and starts the play thread
     * @param filename: filepath of the sound file to start playing
     * @param ap: ProcessSound object
     * @throws javax.sound.sampled.LineUnavailableException
     * @throws javax.sound.sampled.UnsupportedAudioFileException
     * @throws java.io.IOException
     **/

    public PlaySound(String filename, ProcessSound ap) throws LineUnavailableException, UnsupportedAudioFileException, IOException
    {
        this.ap = ap;
        this.filename = filename;        

        File soundFile = new File(filename);
        Mixer mixer = null;
        Info[] info = AudioSystem.getMixerInfo();
        final int outchan = 2; //For binaural

        audioInputStream = AudioSystem.getAudioInputStream(soundFile);
        orgFormat = audioInputStream.getFormat();
        audioFormat = new AudioFormat(orgFormat.getEncoding(),
                                      orgFormat.getSampleRate(),
                                      orgFormat.getSampleSizeInBits(),
                                      outchan,
                                      outchan * orgFormat.getFrameSize() / orgFormat.getChannels(),
                                      orgFormat.getFrameRate(), orgFormat.isBigEndian());        
        System.out.println(audioFormat);


        mixer = AudioSystem.getMixer(info[0]);


        DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class, audioFormat);
        sourceDataLine = (SourceDataLine) mixer.getLine(dataLineInfo);

        //Buffers for sound processing
        tempBuffer = new byte[orgFormat.getFrameSize() * WORKSIZE];
        workBuffer = new double[audioFormat.getChannels()][BUFFSIZE];
        workBuffer2 = new double[2][BUFFSIZE];        
        outBuffer = new byte[orgFormat.getFrameSize() * WORKSIZE];

        this.setPriority(Thread.NORM_PRIORITY);
        this.start();

    }


    @Override
    public void run()
    {
        try
        {
            convin = ByteConvertFactory.createConverter(orgFormat);
            convout = ByteConvertFactory.createConverter(audioFormat);
            sourceDataLine.open(audioFormat);
            sourceDataLine.start();
            FloatControl f = (FloatControl)sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);

            int readbytes = WORKSIZE * orgFormat.getFrameSize();
            int cnt;
            int frames;

            while ((cnt = audioInputStream.read(tempBuffer, 0, readbytes)) != -1)
            {
                if (cnt > 0)
                {

                    frames = cnt / orgFormat.getFrameSize();

                    if (frames < WORKSIZE)
                    {
                        //System.out.println(frames);
                    }


                    for (int i = 0; i < audioFormat.getChannels(); i++)
                    {
                        convin.fromBytes(tempBuffer, workBuffer[i], frames, orgFormat.getChannels(), 0);
                    }


                    for (int i = 0; i < audioFormat.getChannels(); i++)
                    {
                        Arrays.fill(workBuffer[i], WORKSIZE, workBuffer[i].length - 1, 0.);
                    }

                    ap.process(workBuffer, workBuffer2, frames, threshold);                    

                    convout.toBytes(workBuffer2, outBuffer, frames);

                    float volume = 0;
                    if(UserInterface.sliderSystemVolume.getValue() == 0)
                        volume = -3;
                    else
                        volume = (10 * (float)Math.log10(UserInterface.sliderSystemVolume.getValue())) / 6;

                    f.setValue(volume);
                    
                    sourceDataLine.write(outBuffer, 0, audioFormat.getFrameSize() * cnt / orgFormat.getFrameSize());

                }
            }
            
            sourceDataLine.drain();
            sourceDataLine.close();

        }
        catch (Exception e)
        {
            System.out.println("PlaySound: " + e);
            e.printStackTrace();
            UserInterface.lstCurrentPlaying.remove(filename);
            JOptionPane.showMessageDialog(null, "Could not play file " + filename + ".\nPlease try again and Select only .wav file.", "ERROR", 0);
        }

    }
    
} //End of class