/**
 *
 * @author Sanket Jain
 * @author Akshay Wadhwa
 *
 **/


package sound;

import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class Main
{    
    ProcessSound ap;
    PlaySound p = null;
    String filepath;       
    Rectangle2D.Float sourceRect;   //Rectangle representing the individual sound source on Sound Field


    /**
     * Constructor: Initialize ProcessSound Parameters
     * R: Radial Distance from the center of the head
     * azimuth: Angle of rotation in the xy-plane measured with Positive X-Axis on the left
     * elevation: Angle of elevation made with the xy-plane and the Z-axis
     **/

    public Main(String filepath, double R, double azimuth, double elevation)
    {

        this.filepath = filepath;

        ap = new ProcessSound();

        //Radial Distance
        ap.R = R;
        ap.init_R = R;
        ap.prev_R = R;

        //Azimuth
        ap.azimuth = azimuth;
        ap.init_azimuth = azimuth;
        
        //Elevation
        ap.elevation = elevation;

        //Create a rectangle with UI        
        sourceRect = new Rectangle2D.Float();        

    }



    /**
     * startPlayer: Create a PlaySound Thread to play the Wav File location given as input parameter
     * @throws javax.sound.sampled.UnsupportedAudioFileException
     * @throws java.io.IOException
     * @throws javax.sound.sampled.LineUnavailableException
     **/

    public void startPlayer() throws UnsupportedAudioFileException, IOException, LineUnavailableException
    {               
        p = new PlaySound (filepath, ap);        
        System.out.println(filepath.substring(filepath.lastIndexOf("/") + 1) + " is playing");
    }


    /**
     * stopPlayer: Stop Playing the Sound File
     **/

    public void stopPlayer()
    {
        if(p.isAlive())
        {
            p.stop();
            p.suspend();
        }

        System.out.println(filepath.substring(filepath.lastIndexOf(File.separator) + 1) + " Stopped");
    }



    /**
     * setRadius: Set the Radial Distance for the sound source
     * Note: Increasing radius decreases amplitude, and vice-versa
     * @param R: Radial distance from the center of the head
     **/

    public void setRadius(double R)
    {
        this.p.ap.R = R * 0.01;
    }


    /**
     * getRadius: Get the current Radial Distance of the sound source
     * @return: Radius
     **/
    public double getRadius()
    {
        return this.p.ap.R * 100;
    }



    /**
     * getInitialRadius: Get the Initial Radial Distance of the sound source
     * @return: Radius
     **/
    public double getInitRadius()
    {
        return this.p.ap.init_R * 100;
    }


    /**
     * setRadius: Set the Radial Distance for the sound source
     * Note: Increasing radius decreases amplitude, and vice-versa
     * @param R: Radial distance from the center of the head
     **/

    public void setPrevRadius(double R)
    {
        this.p.ap.prev_R = R * 0.01;
    }



    /**
     * getPrevRadius: Get the Previous Radial Distance of the sound source
     * @return: Radius
     **/
    public double getPrevRadius()
    {
        return this.p.ap.prev_R * 100;
    }


    /**
     * setAzimuth: Set the Azimuth for the sound source
     * @param azimuth: Angle of azimuth for the sound source
     **/

    public void setAzimuth(double azimuth)
    {        
        this.p.ap.azimuth = azimuth;        
    }   


    /**
     * getAzimuth: Get the current Azimuth for the sound source
     * @return: Azimuth
     **/

    public double getAzimuth()
    {
        return this.p.ap.azimuth;
    }


    /**
     * getInitialAzimuth: Get the Initial Azimuth for the sound source
     * @return: Radius
     **/
    public double getInitAzimuth()
    {
        return this.p.ap.init_azimuth;
    }

    /**
     * setElevation: Set the Elevation for the sound source
     * @param elevation: Angle of elevation for the sound source
     **/
    public void setElevtion(double elevation)
    {
        this.p.ap.elevation = elevation;        
    }


    /**
     * getElevation: Get the current Elevation for the sound source
     * @return: Elevation
     **/

    public double getElevation()
    {
        return this.p.ap.elevation;
    }


} // End of class