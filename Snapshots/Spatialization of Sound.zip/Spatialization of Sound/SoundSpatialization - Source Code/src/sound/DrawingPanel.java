/**
 *
 * @author Sanket Jain
 * @author Akshay Wadhwa
 * 
 **/

package sound;

import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;


public class DrawingPanel extends JPanel
{        
    static Graphics2D g2d;                                //Java 2D Graphics object
    static double R = 2;                                  //Radius of circular sound field (scaled down for representing purpose)
    static int offset = 20;                               //offset from the left of the JPanel for drawing the circle of sound field
    MovingSoundRectangle ma = new MovingSoundRectangle(); //Create an object of the actionlistener class for moving rectangle in sound field on mouse click
    static Main lastMovedSource;
    static double lastMovedRadius, lastMovedAzimuth;
    static boolean flag = false;


    /**
     * Contructor: Simply adds the Mouse Listeners to the Drawing Panel
     **/

    public DrawingPanel()
    {
        addMouseListener(ma);
        addMouseMotionListener(ma);
    }



    /**
     * paint: Paint method of JPanel overridden to draw the Sound Field dynamically (JAVA 2D)
     * @param g: Graphics component
     **/

    @Override
    public void paint(final Graphics g)
    {
        super.paint(g);        
        //System.out.println("DrawingPanel: Repainted");
        g2d = ((Graphics2D) g);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        g2d.setBackground(Color.WHITE);
        g2d.setStroke(new BasicStroke(4)); // Outer Main circle
        g2d.drawOval(offset, offset, (int)(2 * R * 100), (int) (2 * R * 100));
        g2d.setColor(Color.WHITE);
        g2d.fillOval(offset, offset, (int)(2 * R * 100), (int)(2 * R * 100));


        //Sector for the current head position -- range 10 degrees
        //+ R*100/8*Math.sin((UserInterface.headangle-180)*Math.PI/180)
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillArc(offset, offset, (int)(2 * R * 100 ), (int)(2 * R * 100 ), -(int)(UserInterface.headangle + 180 - UserInterface.headFocusAngle), -(int)UserInterface.headFocusAngle * 2);  //Negative start_angle and arc+extent angle because clockwise rotation
        g2d.setStroke(new BasicStroke(1));
        g2d.setColor(Color.GRAY);
        g2d.drawLine((int)(offset + R * 100), (int)(offset + R * 100) , (int)(offset + R * 100 + (int)(R * 100 * Math.cos(Math.PI /180 * (UserInterface.headangle + 180)))), (int)(offset + R * 100 + (int)(R * 100 * Math.sin(Math.PI / 180 * (UserInterface.headangle + 180)))));

        //Background circles and Radial Lines
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(1));
        g2d.drawOval(offset + (int)R*100/2, offset + (int)R*100/2, (int)(2 * R/2 * 100), (int) (2 * R/2 * 100));
        g2d.drawOval(offset + (int)R*100/4, offset + (int)R*100/4, (int)(2 * 3*(int)R*100/4), (int) (2 * 3*(int)R*100/4));
        g2d.drawOval(offset + 3*(int)R*100/4, offset + 3*(int)R*100/4, (int)(2 * R/4 * 100), (int) (2 * R/4 * 100));
        for(int angle = 0; angle < 360; angle+=45)
        {
            g2d.drawLine((int)(offset + R * 100), (int)(offset + R * 100) , (int)(offset + R * 100 + (int)(R * 100 * Math.cos(Math.PI /180 * angle))), (int)(offset + R * 100 + (int)(R * 100 * Math.sin(Math.PI / 180 * angle))));
        }

        //Drawing Random Color Lines for each sound source along with a rectangle at the tip
        g2d.setStroke(new BasicStroke(4));
        Random randomGen = new Random(10000000);
        for(int i=0; i<UserInterface.playList.size(); i++)
        {
            Main m = (Main) UserInterface.playList.get(i);
            if(m.p == null)
                continue;

            double theta = (m.getAzimuth() * 2 + 180) %360;

            Color c = new Color(randomGen.nextInt());
            g2d.setColor(c);

            double soundradius = (m.getInitRadius() / m.getRadius() * 2);
            if(soundradius > R) { soundradius = R; }
            g2d.drawLine((int)(offset + R * 100), (int)(offset + R * 100) , (int)(offset + R * 100 + (int)(soundradius * 100 * Math.cos(Math.PI /180 * theta))), (int)(offset + R * 100 + (int)(soundradius * 100 * Math.sin(Math.PI / 180 * theta))));
            m.sourceRect.setRect((int)(offset + R * 100 - 10 + (int)(soundradius * 100 * Math.cos(Math.PI /180 * theta))), (int)(offset + R * 100 - 10 + (int)(soundradius * 100 * Math.sin(Math.PI / 180 * theta))), 20, 20);
            g2d.fill(m.sourceRect);
        }

        //Drawing the head at the center
        if(UserInterface.chkViewHeadImage.isSelected())
        {
            g2d.setStroke(new BasicStroke(4));
            g2d.setColor(Color.BLACK);
            g2d.drawOval(offset + (int)(15*R*100/16 - 2.5+2*R/16*100), offset + 15*(int)R*100/16 + 7, (int)(2 * R/16 * 100 - 15), (int) (2 * R/16 * 100 - 15));
            g2d.drawOval(offset + 15*(int)R*100/16 - 8, offset + 15*(int)R*100/16 + 6, (int)(2 * R/16 * 100 - 15), (int) (2 * R/16 * 100 - 15));
            g2d.setColor(Color.YELLOW);
            g2d.fillOval(offset + (int)(15*R*100/16 - 2.5+2*R/16*100), offset + 15*(int)R*100/16 + 7, (int)(2 * R/16 * 100 - 15), (int) (2 * R/16 * 100 - 15));
            g2d.fillOval(offset + 15*(int)R*100/16 - 8, offset + 15*(int)R*100/16 + 6, (int)(2 * R/16 * 100 - 15), (int) (2 * R/16 * 100 - 15));
            g2d.setColor(Color.BLACK);
            g2d.drawOval(offset + 15*(int)R*100/16, offset + 15*(int)R*100/16, (int)(2 * R/16 * 100), (int) (2 * R/16 * 100));
            g2d.setColor(Color.GRAY);
            g2d.fillOval(offset + 15*(int)R*100/16, offset + 15*(int)R*100/16, (int)(2 * R/16 * 100), (int) (2 * R/16 * 100));

        }
    }




    /**
     * Inner Class MovingSoundRectangle: Action listener for the Sound Field
     **/
    class MovingSoundRectangle extends MouseAdapter
    {
        private int x;
        private int y;
        

        /**
         * Mouse Pressed Event
         * @param e
         **/

        @Override
        public void mousePressed(MouseEvent e)
        {            
            x = e.getX();
            y = e.getY();
        }



        /**
         * Mouse Drag Event
         * @param e
         **/
        
        @Override
        public void mouseDragged(MouseEvent e)
        {          
            int dx = e.getX() - x;
            int dy = e.getY() - y;

            for(int i = UserInterface.playList.size() - 1 ; i >= 0; i--) //For loop in reverse to order because only upper source should be moved when two sources are stuck up
            {
                Main m = (Main) UserInterface.playList.get(i);
                if(m.p == null)
                    continue;

                if(m.sourceRect.getBounds2D().contains(x,y))
                {
                    if(flag == false)
                    {
                        lastMovedSource = m;
                        lastMovedAzimuth = m.getAzimuth();
                        lastMovedRadius = m.getRadius();
                        flag = true;
                        UserInterface.btnUndoMove.setEnabled(true);
                        UserInterface.btnReset.setEnabled(true);                       
                    }

                    //Slope of the Line == TanInverse (( y1-y2)/(x1-x2)) and then CONVERTED FROM RADIANS TO DEGREES
                    double newAzimuth = 0;
                    double newRadius = 0;
                    
                    //Calculate new radius and azimuth of the sound source
                    newRadius = R*100 / Math.sqrt((x+dx - offset - R*100)*(x+dx - offset - R*100) + (y+dy - offset - R*100)*(y+dy - offset - R*100)) * m.getInitRadius();
                    newAzimuth = Math.atan((offset + R * 100 - y - dy) / (offset + R * 100 - x - dx)) * 180 / Math.PI;

                    //Check if the angle is in right half circle or left half circle, since atan() gives output between -90 to +90
                    if((offset + R * 100 - x - dx) < 0) //Right half
                    {                        
                        newAzimuth = 180 + newAzimuth;
                    }
                    else // Left half
                    {
                        newAzimuth = (360 + newAzimuth) %360;
                    }

                    //Set the radius and the azimuth
                    m.setPrevRadius(m.getRadius());
                    m.setRadius(newRadius);                    
                    m.setAzimuth(newAzimuth/2);

                    System.out.println("NewAzimuth= " + newAzimuth + "\tCoordinates: x=" + (offset + R * 100 - x - dx) + ", y=" + (offset + R * 100 - y - dy) + "  NewRadius: " + newRadius);
                    
                    break; //To avoid moving two overlapping sources together forever. Only one source to be moved at a time
                }

                repaint();
            }
                        
            //Update original x,y of the rectangle
            x += dx;
            y += dy;

        }


        /**
         * Mouse Release event
         * @param e
         **/
        @Override
        public void mouseReleased(MouseEvent e)
        {            
            UserInterface.checkIfInHeadFocus(3);
            repaint();
            flag = false;            
        }
        
    } // End of Inner Class MovingSoundRectangle

} // End of Class DrawingPanel